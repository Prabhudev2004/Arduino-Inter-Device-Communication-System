
# 📡 Arduino Communication Protocol

## 🔶 Packet Format

```
[START_BYTE] [COMMAND] [DATA] [END_BYTE]
```

### Byte Definitions

| Byte         | Value    | Description               |
|--------------|----------|---------------------------|
| START_BYTE   | 0x02     | Start of message          |
| CMD_PING     | 0x01     | Check connectivity        |
| CMD_STATUS   | 0x02     | Ask device status         |
| CMD_UPTIME   | 0x03     | Get time since boot       |
| END_BYTE     | 0x03     | End of message            |

## 🔄 Example

**Master Sends:**
```
[0x02, 0x01, 0x00, 0x03] // CMD_PING
```

**Slave Replies:**
```
[0x02, 0xAA, 0x03] // PONG
```

## 🛠 Notes

- Data byte is dummy for now.
- Add CRC later for data integrity.
